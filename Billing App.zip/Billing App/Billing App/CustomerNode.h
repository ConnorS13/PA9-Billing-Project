#pragma once
#include"CustomerData.h"

// 
template <typename T>
class CustomerNode
{
public:
	// constructors etc
	CustomerNode();
	~CustomerNode();
	// setters 
	void setdata(T* insert);
	void operator = (CustomerNode<T>* rhs);
	void setnextnode(CustomerNode<T>* next = nullptr);
	// getters
	CustomerNode<T>* getnextCustomerNode();
	T* getdata();
	bool badCustomerNode();
private:
	T* data;
	CustomerNode<T>* nextCustomerNode;
};

template<typename T>
CustomerNode<T>::CustomerNode()
{
	this->data = NULL;
	this->nextCustomerNode = NULL;
}

template<typename T>
inline CustomerNode<T>::~CustomerNode()
{
	delete this->data;
	this->nextCustomerNode = NULL;
}

template<typename T>
void CustomerNode<T>::setdata(T* insert)
{
	this->data = insert;
}

template<typename T>
CustomerNode<T>* CustomerNode<T>::getnextCustomerNode()
{
	return this->nextCustomerNode;
}

template<typename T>
void CustomerNode<T>::setnextnode(CustomerNode<T>* next)
{
	this->nextCustomerNode = next;
}

template<typename T>
inline T* CustomerNode<T>::getdata()
{
	return this->data;
}

template<typename T>
void CustomerNode<T>::operator=(CustomerNode<T>* rhs)
{
	this->data = rhs->data;
	this->nextCustomerNode = rhs->nextCustomerNode;
}