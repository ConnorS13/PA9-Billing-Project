#pragma once
#include "CustomerNode.h"

// this is straight from PA 7 with just the names changed 

template <typename N>
class CustomerList
{
public:
	// initilizers etc. 
	CustomerList();
	~CustomerList();
	void deleteall(CustomerNode<N>* head);
	// setters 
	void insertfront(CustomerNode<N>* nCustomerNode);


	//getters 
	CustomerNode<N>* gethead();
	CustomerNode<N>* getNextptr(CustomerNode<N>* nCustomerNode);

private:
	CustomerNode<N>* mpHead; // initilized to nullptr
	//N* mpHead; 
};

template<typename N>
CustomerList<N>::CustomerList()
{
	this->mpHead = NULL;

}

template<typename N>
inline CustomerList<N>::~CustomerList()
{
	this->deleteall(this->mpHead);
	this->mpHead = NULL;
}

template<typename N>
inline void CustomerList<N>::deleteall(CustomerNode<N>* head)
{
	head = NULL;
	////head = head->getnextCustomerNode();
	//if (head->getnextCustomerNode()!= nullptr)
	//{
	   // // recursivly cycle through the tree until you delete all
	   // head = head->getnextCustomerNode();

	   // deleteall(head); // after a bit this line kept on throwing a weird error
	   // head->~CustomerNode(); 
	   // 
	//}
}

template<typename N>
void CustomerList<N>::insertfront(CustomerNode<N>* nCustomerNode)
{
	if (nCustomerNode->badCustomerNode() != true)
	{
		if (!this->mpHead)
		{
			nCustomerNode->setnextnode();
			this->mpHead = nCustomerNode;
		}
		else
		{
			nCustomerNode->setnextnode(this->mpHead);
			this->mpHead = nCustomerNode;
		}
	}




	/*if (!this->mpHead)
	{
		nCustomerNode->setnextnode();
		this->mpHead = nCustomerNode;
	}
	else
	{
		nCustomerNode->setnextnode(this->mpHead);
		this->mpHead = nCustomerNode;
	}*/
}

//template<typename N>
//inline void CustomerList<N>::insertfront(CustomerNode<N>* nCustomerNode)//Data replaced the N
//{
//	nCustomerNode->setnextnode(this->mpHead->getnextCustomerNode()); 
//	this->mpHead->setnextnode(nCustomerNode);
//}

template<typename N>
CustomerNode<N>* CustomerList<N>::gethead()
{
	return this->mpHead;
}

template<typename N>
CustomerNode<N>* CustomerList<N>::getNextptr(CustomerNode<N>* nCustomerNode)
{
	return nCustomerNode->nextCustomerNode;
}



