#pragma once

#include <iostream> // cout, cin, endl <<, >>
#include <string>
#include <fstream>
#include <vector>
#include<ctime>
#pragma warning(disable : 4996)// turns off the _crt_secure... messag

class CustomerData
{
public: 

private: 

	int regularMaintnanceCharge; // user set 
	std::string regularMaintnanceName; // user set
	///the user only hase one option for regular maintance, as of now, 
	/// mabey we could add a vesctor of structs that contained the 
	/// names and the charges to a couple of regular maintance items 
	/// but as of now I need to go to class so i cant do taht quite yet. 
	/// 
	int houseNumber; 
	std::string roadName; 
	std::string cityName; 
	std::string areaCode; 
	std::string billingAdress; 
	std::string firstName; 
	std::string lastName; 
	
};
